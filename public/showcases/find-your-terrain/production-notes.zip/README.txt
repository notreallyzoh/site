FIND YOUR TERRAIN — PRODUCTION NOTES & EDIT FILES
By Zoheb Mamoo | Self-initiated concept ad | 2026

This fictional expedition shoe was developed as a portfolio exploration of
AI-assisted product design and advertising. It is not a physical prototype
or a commissioned commercial campaign.

DELIVERED
60-second landscape film: 1920 x 1080, 24fps, H.264/AAC.
30-second vertical reel: 1080 x 1920, 24fps, H.264/AAC.
Both exports are text-free and finish with a hovering product reveal.
The reel repurposes 25 seconds of footage and adds a five-second portrait hero.

IN THIS PACK
- Four approved product references, optimized for web.
- Actual prompt examples and settings for the portrait keyframe, motion and music.
- Landscape and portrait edit manifests.
- Python assembly scripts and the final color adjustment file.

This is a supporting-files pack for inspecting the production decisions.
It does NOT contain the source clip library, generated music tracks or final
MP4s. Final films can be downloaded separately from the case-study page.
The prompt references must be supplied in your own generation session.

WORKFLOW
Product exploration -> approved references -> scene keyframes ->
image-to-video clips -> editorial assembly -> visual/audio review ->
revisions -> portrait reframing and a newly composed hero.

TOOLS
Higgsfield MCP orchestration; Seedream 5.5 keyframes; Kling 4.0 motion;
Seedance 2.5 in earlier reused clips; ElevenLabs Music v2 instrumental
music; Python, NumPy, Pillow, OpenCV, FFmpeg and FFprobe for editing/exports.

EDIT DECISIONS
Keep product silhouette, material palette and panel layout consistent.
Use short transitions, retain the trail run, hop and alpine reveal.
Replace the title ending with a controlled hover and turn in the forest.
Reframe each landscape shot individually for portrait; generate a fresh
portrait hero so the complete shoe has space to rotate.

READING / REBUILDING
Inspect smooth-manifest.json for the 60-second timeline and transitions.
Inspect reel/reel-plan.json for source in-points, crop tracks and audio.
To rebuild, first restore every source file named by the plans/scripts.
With dependencies installed, use:
  python assemble_smooth.py --grades grades.json
  python reel/assemble_reel.py
assemble.py supplies shared helpers to assemble_smooth.py. It also retains
an older title-rendering entry point; use assemble_smooth.py for the final
text-free version. The source videos and music are intentionally omitted
from this small public pack. No generation credentials or billing data
are included.
