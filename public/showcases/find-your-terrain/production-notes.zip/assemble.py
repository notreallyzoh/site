#!/usr/bin/env python3
"""Assemble THE VIEW: exactly 60 seconds, photographic cuts, one final title.

Run in /home/user/the-view:
  python assemble.py --preview       # source-based review sheet; no full render
  python assemble.py                 # full film and verified review sheet
  python assemble.py --audio-only    # remix existing video-master.mp4

Requires ffmpeg, ffprobe and Pillow. No generation, network or paid calls.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageStat


WIDTH, HEIGHT, FPS, DURATION = 1920, 1080, 24, 60
TITLE = "Find your Terrain"
IVORY = (241, 237, 224)
SHOTS = [
    {"file":"scene01.mp4", "duration":7, "start":0, "name":"Ascent"},
    {"file":"existing-action.mp4", "duration":5, "start":7, "name":"Footsteps"},
    {"file":"scene02.mp4", "duration":6, "start":12, "name":"Fogbound lookout"},
    {"file":"scene03.mp4", "duration":4, "start":18, "name":"Pause"},
    {"file":"scene04.mp4", "duration":6, "start":22, "name":"Noticing"},
    {"file":"existing-macro.mp4", "duration":4, "start":28, "name":"Material detail"},
    {"file":"scene05.mp4", "duration":5, "start":32, "name":"Small landscape"},
    {"file":"scene06.mp4", "duration":5, "start":37, "name":"Continuing"},
    {"file":"scene08.mp4", "duration":4, "start":42, "name":"Mountain trail run"},
    {"file":"scene09.mp4", "duration":3, "start":46, "name":"Low trail hop"},
    {"file":"scene07.mp4", "duration":5, "start":49, "name":"Alpine panorama"},
    {"file":"existing-forest.mp4", "duration":3, "start":54, "name":"Product hero"},
    {"file":"existing-forest.mp4", "duration":3, "start":57, "name":"Final hold", "freeze":True},
]
REVIEW_TIMES = [shot["start"]+shot["duration"]/2 for shot in SHOTS]


def run(command):
    subprocess.run([str(item) for item in command], check=True)


def probe(path, count_frames=False):
    command = ["ffprobe", "-v", "error"]
    if count_frames:
        command += ["-count_frames"]
    command += ["-show_streams", "-show_format", "-of", "json", str(path)]
    return json.loads(subprocess.check_output(command))


def font_path():
    for name in [
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "C:/Windows/Fonts/arial.ttf",
    ]:
        if Path(name).exists():
            return name
    raise RuntimeError("A regular Liberation Sans, DejaVu Sans or Arial font is required.")


def validate_grades(data):
    """Optional bounded eq controls; omitted values remain exactly neutral."""
    bounds = {"brightness":(-.1,.1), "contrast":(.8,1.2),
              "saturation":(.7,1.3), "gamma":(.9,1.1)}
    if not isinstance(data, dict):
        raise ValueError("Grades JSON must map asset filenames to eq settings.")
    for filename, settings in data.items():
        if filename not in {shot["file"] for shot in SHOTS}:
            raise ValueError(f"Unknown grade asset: {filename}")
        if not isinstance(settings, dict):
            raise ValueError(f"Grade for {filename} must be an object.")
        for key, value in settings.items():
            if key not in bounds or not isinstance(value,(int,float)):
                raise ValueError(f"Unsupported grade setting: {filename}/{key}")
            low,high = bounds[key]
            if not low <= value <= high:
                raise ValueError(f"Grade {key} must be within {low}..{high}")
    return data


def visual_filter(width, height, grade=None):
    filters = [
        f"scale={width}:{height}:force_original_aspect_ratio=increase:flags=lanczos",
        f"crop={width}:{height}", "setsar=1",
    ]
    if grade:
        neutral = {"brightness":0, "contrast":1, "saturation":1, "gamma":1}
        values = {**neutral, **grade}
        if values != neutral:
            filters.append("eq="+":".join(f"{k}={v}" for k,v in values.items()))
    return ",".join(filters)


def encode_options(args):
    # Even a sustained maximum rate plus AAC stays comfortably below 50 MB.
    return ["-c:v","libx264", "-preset",args.preset, "-crf",str(args.crf),
            "-maxrate","5000k", "-bufsize","10000k", "-threads","2",
            "-pix_fmt","yuv420p", "-g","48", "-keyint_min","24",
            "-color_primaries","bt709", "-color_trc","bt709", "-colorspace","bt709",
            "-video_track_timescale","12288", "-movflags","+faststart"]


def check_video(path, frames, expected_audio=False):
    info = probe(path)
    video = next(stream for stream in info["streams"] if stream["codec_type"] == "video")
    count = video.get("nb_frames")
    if count in (None,"N/A"):
        info = probe(path, count_frames=True)
        video = next(stream for stream in info["streams"] if stream["codec_type"] == "video")
        count = video.get("nb_read_frames")
    if int(count or -1) != frames:
        raise RuntimeError(f"{path.name}: expected {frames} frames, found {count}")
    if (video["width"],video["height"]) != (WIDTH,HEIGHT):
        raise RuntimeError(f"{path.name}: incorrect dimensions")
    numerator, denominator = map(int,video["avg_frame_rate"].split("/"))
    if numerator/denominator != FPS:
        raise RuntimeError(f"{path.name}: incorrect frame rate")
    video_duration = float(video.get("duration", frames/FPS))
    if abs(video_duration-frames/FPS) > .001:
        raise RuntimeError(f"{path.name}: unexpected video duration {video_duration}")
    audio_stats = {}
    if expected_audio:
        audio = next((s for s in info["streams"] if s["codec_type"] == "audio"),None)
        if audio is None:
            raise RuntimeError(f"{path.name}: missing audio stream")
        audio_duration = float(audio.get("duration",0))
        if abs(audio_duration-frames/FPS) > .025:
            raise RuntimeError(f"{path.name}: audio duration is {audio_duration}, expected {frames/FPS}")
        if audio.get("codec_name") != "aac" or int(audio.get("sample_rate",0)) != 48000:
            raise RuntimeError(f"{path.name}: expected AAC audio at 48 kHz")
        audio_stats = {"audio_duration":audio_duration,"audio_codec":audio["codec_name"],
                       "audio_sample_rate":int(audio["sample_rate"])}
    return {"frames":int(count), "duration":video_duration, **audio_stats,
            "container_duration":float(info["format"]["duration"]),
            "width":WIDTH, "height":HEIGHT, "fps":FPS, "bytes":path.stat().st_size}


def normalise_clip(root, shot, output, args, grades):
    frames = shot["duration"]*FPS
    vf = (f"fps={FPS},"+visual_filter(WIDTH,HEIGHT,grades.get(shot["file"]))+
          f",tpad=stop_mode=clone:stop_duration={shot['duration']},"
          f"trim=end_frame={frames},setpts=PTS-STARTPTS,format=yuv420p")
    run(["ffmpeg","-hide_banner","-loglevel","warning","-y",
         "-i",root/shot["file"], "-map","0:v:0", "-an", "-sn", "-dn",
         "-vf",vf, "-frames:v",str(frames), "-fps_mode","cfr",
         *encode_options(args), output])
    return check_video(output,frames)


def title_layer(size):
    width,height = size
    layer = Image.new("RGBA",size,(0,0,0,0))
    draw = ImageDraw.Draw(layer)
    font = ImageFont.truetype(font_path(),round(62*height/HEIGHT))
    draw.text((round(.1*width),round(.12*height)),TITLE,
              font=font,fill=(*IVORY,255),anchor="lt")
    return layer


def make_hold(previous_segment, output, work, args, previous_duration, hold_duration):
    still = work/"hero-last-frame.png"
    title = work/"title.png"
    previous_last_frame = round(previous_duration*FPS)-1
    hold_frames = round(hold_duration*FPS)
    run(["ffmpeg","-hide_banner","-loglevel","warning","-y",
         "-i",previous_segment, "-vf",f"select=eq(n\\,{previous_last_frame})",
         "-fps_mode","vfr", "-frames:v","1", "-update","1",still])
    title_layer((WIDTH,HEIGHT)).save(title)
    graph = ("[0:v]format=rgba[base];"
             "[1:v]format=rgba,fade=t=in:st=0:d=0.7:alpha=1[title];"
             "[base][title]overlay=0:0:format=auto,format=yuv420p[v]")
    run(["ffmpeg","-hide_banner","-loglevel","warning","-y",
         "-loop","1", "-framerate",str(FPS), "-i",still,
         "-loop","1", "-framerate",str(FPS), "-i",title,
         "-filter_complex_threads","1", "-filter_complex",graph,
         "-map","[v]", "-an", "-frames:v",str(hold_frames),
         *encode_options(args),output])
    return check_video(output,hold_frames)


def mix_audio(root, master, output, forest_ambience=False, action_audio=True):
    music = root/"music.mp3"
    if not music.exists():
        raise FileNotFoundError("music.mp3 is required for the approved music-led cut.")
    command = ["ffmpeg","-hide_banner","-loglevel","warning","-y",
               "-i",master, "-i",music]
    filters = [
        "[1:a]aresample=48000,aformat=channel_layouts=stereo,"
        "loudnorm=I=-19:TP=-2:LRA=9,apad,atrim=duration=60,"
        "afade=t=in:st=0:d=1.0,afade=t=out:st=57.5:d=2.5[music]"
    ]
    labels = ["[music]"]
    audio_sources = ["music.mp3"]
    input_index = 2
    # New scene audio is excluded. Forest audio requires explicit confirmation
    # that it contains usable ambience, without speech or embedded music.
    # Existing action sound plays only alongside that exact 7–12 second clip.
    for filename,kind in [("existing-forest.mp4","forest"),("existing-action.mp4","steps")]:
        if (kind == "forest" and not forest_ambience) or (kind == "steps" and not action_audio):
            continue
        source = root/filename
        if not any(stream["codec_type"] == "audio" for stream in probe(source)["streams"]):
            continue
        command += (["-stream_loop","-1", "-i",source] if kind == "forest" else ["-i",source])
        if kind == "forest":
            filters.append(
                f"[{input_index}:a]aresample=48000,aformat=channel_layouts=stereo,"
                "atrim=duration=60,asetpts=PTS-STARTPTS,highpass=f=110,lowpass=f=7500,"
                "volume=0.12,afade=t=in:st=0:d=1.3,afade=t=out:st=57.5:d=2.5[forest]")
            labels.append("[forest]")
        else:
            filters.append(
                f"[{input_index}:a]aresample=48000,aformat=channel_layouts=stereo,"
                "atrim=duration=5,asetpts=PTS-STARTPTS,volume=0.16,"
                "afade=t=in:st=0:d=0.15,afade=t=out:st=4.75:d=0.25,"
                "adelay=7000|7000,apad,atrim=duration=60[steps]")
            labels.append("[steps]")
        audio_sources.append(filename)
        input_index += 1
    filters.append("".join(labels)+f"amix=inputs={len(labels)}:duration=longest:normalize=0,"
                   "alimiter=limit=0.95:level=false,atrim=duration=60,asetpts=PTS-STARTPTS[mix]")
    command += ["-filter_complex_threads","1", "-filter_complex",";".join(filters),
                "-map","0:v:0", "-map","[mix]", "-c:v","copy",
                "-c:a","aac", "-b:a","192k", "-ar","48000",
                "-t","60", "-movflags","+faststart",output]
    run(command)
    return audio_sources


def extract_frame(path, second, size, grade=None):
    duration = float(probe(path)["format"]["duration"])
    second = max(0,min(second,duration-1/FPS))
    command = ["ffmpeg","-hide_banner","-loglevel","error",
               "-ss",f"{second:.6f}", "-i",str(path),
               "-map","0:v:0", "-frames:v","1", "-an",
               "-vf",visual_filter(*size,grade),
               "-f","image2pipe", "-vcodec","png","pipe:1"]
    return Image.open(io.BytesIO(subprocess.check_output(command))).convert("RGB")


def last_frame_check(master, final, work):
    """Decode the actual terminal frame, verify the mux, and inspect title pixels."""
    def decode(path, total_frames):
        # Seek a microsecond before the last frame's exact timestamp so rounding
        # cannot request a nonexistent frame after the end of the stream.
        second = (total_frames-1)/FPS-0.000001
        command = ["ffmpeg","-hide_banner","-loglevel","error",
                   "-ss",f"{second:.6f}","-i",str(path),"-map","0:v:0",
                   "-frames:v","1","-an","-pix_fmt","rgb24",
                   "-f","rawvideo","pipe:1"]
        raw = subprocess.check_output(command)
        if len(raw) != WIDTH*HEIGHT*3:
            raise RuntimeError(f"{path.name}: final frame did not decode completely")
        return raw
    raw = decode(final,FPS*DURATION)
    if raw != decode(master,FPS*DURATION):
        raise RuntimeError("Final mux changed or truncated the terminal video frame")
    result = {"decoded":True,"sha256":hashlib.sha256(raw).hexdigest(),
              "matches_video_master":True}
    hold = work/f"shot-{len(SHOTS):02d}.mp4"
    if hold.exists():
        if raw != decode(hold,round(SHOTS[-1]["duration"]*FPS)):
            raise RuntimeError("Final frame does not match the approved three-second hold")
        result["matches_final_hold_segment"] = True
    still = work/"hero-last-frame.png"
    if still.exists():
        title = title_layer((WIDTH,HEIGHT))
        expected = Image.alpha_composite(Image.open(still).convert("RGBA"),title).convert("RGB")
        actual = Image.frombytes("RGB",(WIDTH,HEIGHT),raw)
        difference = ImageChops.difference(actual,expected)
        # Measure the actual glyph pixels, not a large mostly-background box.
        errors = ImageStat.Stat(difference,mask=title.getchannel("A")).mean
        error = sum(errors)/3
        if error > 20:
            raise RuntimeError(f"Final title pixels differ from the expected title: mean error {error:.2f}")
        result["title_glyph_mean_error"] = round(error,3)
        result["title_visible_on_last_frame"] = True
    return result


def save_review_jpeg(sheet, output):
    """Keep the shot review below the tool's 500 KiB display threshold."""
    limit = 500*1024
    while True:
        for quality in [88,80,72,64,56,48,40]:
            encoded = io.BytesIO()
            sheet.save(encoded,format="JPEG",quality=quality,optimize=True,progressive=True)
            if encoded.tell() <= limit:
                output.write_bytes(encoded.getvalue())
                return
        sheet = sheet.resize((round(sheet.width*.85),round(sheet.height*.85)),Image.Resampling.LANCZOS)


def review_sheet(root, output, grades, final=None):
    width,height,label_height = 640,360,30
    rows = (len(SHOTS)+1)//2
    sheet = Image.new("RGB",(width*2,(height+label_height)*rows),(19,24,22))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype(font_path(),17)
    for index,shot in enumerate(SHOTS):
        if final:
            frame = extract_frame(final,REVIEW_TIMES[index],(width,height))
        else:
            # Preview is extracted from real source frames; only final title is added.
            second = shot["duration"]/2
            if shot.get("freeze"):
                source_duration = float(probe(root/shot["file"])["format"]["duration"])
                second = min(SHOTS[index-1]["duration"],source_duration)-1/FPS
            frame = extract_frame(root/shot["file"],second,(width,height),grades.get(shot["file"]))
            if shot.get("freeze"):
                frame = Image.alpha_composite(frame.convert("RGBA"),title_layer((width,height))).convert("RGB")
        x,y = (index%2)*width,(index//2)*(height+label_height)
        sheet.paste(frame,(x,y))
        draw.text((x+10,y+height+5),f"{shot['start']:02d}–{shot['start']+shot['duration']:02d}s  {shot['name']}",font=font,fill=IVORY)
    save_review_jpeg(sheet,output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path.cwd())
    parser.add_argument("--preview",action="store_true")
    parser.add_argument("--audio-only",action="store_true")
    parser.add_argument("--forest-ambience",action="store_true",help="Enable the forest audio bed only after verifying it contains no speech or embedded music")
    parser.add_argument("--mute-action-audio",action="store_true",help="Omit native sound from the existing 7–12 second action shot")
    parser.add_argument("--grades",type=Path,help="Optional JSON map of filename to brightness/contrast/saturation/gamma; neutral by default")
    parser.add_argument("--preset",default="veryfast")
    parser.add_argument("--crf",type=int,default=19)
    args = parser.parse_args()
    if args.preview and args.audio_only:
        parser.error("Choose --preview or --audio-only, not both.")
    root = args.root.resolve()
    root.mkdir(parents=True,exist_ok=True)
    timeline_end = 0
    for shot in SHOTS:
        if shot["start"] != timeline_end:
            raise ValueError(f"Non-contiguous timeline at {shot['name']}")
        timeline_end += shot["duration"]
    if timeline_end != DURATION:
        raise ValueError(f"Timeline must total {DURATION} seconds, found {timeline_end}")
    grades = validate_grades(json.loads(args.grades.read_text(encoding="utf-8"))) if args.grades else {}
    for filename in {shot["file"] for shot in SHOTS}:
        if not (root/filename).exists():
            raise FileNotFoundError(root/filename)
    if args.preview:
        review_sheet(root,root/"review.jpg",grades)
        print(f"Preview saved: {root/'review.jpg'}",flush=True)
        return
    work = root/"render"
    work.mkdir(exist_ok=True)
    master,final = root/"video-master.mp4",root/"final60.mp4"
    segment_stats = []
    if not args.audio_only:
        segments = []
        for index,shot in enumerate(SHOTS):
            output = work/f"shot-{index+1:02d}.mp4"
            print(f"Normalising {index+1}/{len(SHOTS)}: {shot['name']}",flush=True)
            if shot.get("freeze"):
                stats = make_hold(segments[-1],output,work,args,
                                  previous_duration=SHOTS[index-1]["duration"],
                                  hold_duration=shot["duration"])
            else:
                stats = normalise_clip(root,shot,output,args,grades)
            segment_stats.append({"file":output.name,**stats})
            segments.append(output)
        concat = work/"sequence.txt"
        concat.write_text("".join("file '"+str(path.as_posix()).replace("'","'\\''")+"'\n" for path in segments),encoding="utf-8")
        run(["ffmpeg","-hide_banner","-loglevel","warning","-y",
             "-f","concat","-safe","0","-i",concat,
             "-map","0:v:0","-an","-c:v","copy","-movflags","+faststart",master])
    elif not master.exists():
        raise FileNotFoundError("--audio-only requires existing video-master.mp4")
    master_stats = check_video(master,FPS*DURATION)
    audio_sources = mix_audio(root,master,final,forest_ambience=args.forest_ambience,
                              action_audio=not args.mute_action_audio)
    final_stats = check_video(final,FPS*DURATION,expected_audio=True)
    if abs(final_stats["container_duration"]-60) > .025:
        raise RuntimeError(f"Final container is not 60 seconds: {final_stats['container_duration']}")
    if final_stats["bytes"] >= 50_000_000:
        raise RuntimeError("Final exceeds 50 MB; rerun with --crf 22 to reduce size.")
    terminal_frame = last_frame_check(master,final,work)
    review_sheet(root,root/"review.jpg",grades,final=final)
    manifest = {
        "title":"The View", "duration":60, "fps":FPS, "frame_count":1440,
        "resolution":[WIDTH,HEIGHT], "cuts":"Straight photographic cuts; final hero frame held from 57 to 60 seconds.",
        "on_screen_text":{"text":TITLE,"start":57,"end":60,"fade_in_seconds":.7,"font":"regular sans","size_px":62,"position":[.1,.12]},
        "timeline":SHOTS, "grades":grades,
        "audio":{"sources":audio_sources,"new_scene_native_audio":"muted",
                 "forest_bed":"0–60 seconds at low level" if "existing-forest.mp4" in audio_sources else "disabled",
                 "footsteps":"7–12 seconds only, synchronized to the original action clip" if "existing-action.mp4" in audio_sources else "disabled"},
        "outputs":{"video-master.mp4":master_stats,"final60.mp4":final_stats},
        "last_frame_validation":terminal_frame,
        "segments":segment_stats,
    }
    if args.audio_only and (root/"manifest.json").exists():
        previous = json.loads((root/"manifest.json").read_text(encoding="utf-8"))
        manifest["segments"] = previous.get("segments",[])
        manifest["grades"] = previous.get("grades",grades)
    (root/"manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(final_stats,indent=2),flush=True)


if __name__ == "__main__":
    main()
