#!/usr/bin/env python3
"""Independent, text-free 30-second portrait reel assembler.

Run from /home/user/the-view:
  python reel/assemble_reel.py --preview
  python reel/assemble_reel.py
  python reel/assemble_reel.py --audio-only

Edit reel-plan.json to adjust crop-center keyframes. Source in-points and shot
boundaries are integer frames at 24 fps. Requires FFmpeg, FFprobe, Pillow,
NumPy and OpenCV. No network, generation or paid calls are made.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


WIDTH, HEIGHT, FPS, TOTAL_FRAMES = 1080, 1920, 24, 720
DURATION = TOTAL_FRAMES/FPS
FRAME_BYTES = WIDTH*HEIGHT*3
MAX_EDGE_HANDLE = 3


def run(command):
    subprocess.run([str(value) for value in command],check=True)


def probe(path, count_frames=False):
    command = ["ffprobe","-v","error"]
    if count_frames:
        command.append("-count_frames")
    command += ["-show_streams","-show_format","-of","json",str(path)]
    return json.loads(subprocess.check_output(command))


def source_path(root, relative):
    path = (root/relative).resolve()
    try:
        path.relative_to(root)
    except ValueError:
        raise ValueError(f"Source path must stay within the asset root: {relative}")
    return path


def validate_plan(plan):
    if (plan["width"],plan["height"],plan["fps"],plan["duration_frames"]) != (WIDTH,HEIGHT,FPS,TOTAL_FRAMES):
        raise ValueError("This reel must be 1080x1920, 24 fps and exactly 720 frames")
    if plan.get("on_screen_text"):
        raise ValueError("The portrait reel is text-free")
    end = 0
    for index,shot in enumerate(plan["shots"]):
        for field in ["start_frame","duration_frames","source_in_frames","transition_in_frames"]:
            if not isinstance(shot[field],int) or shot[field] < 0:
                raise ValueError(f"{shot['name']}: {field} must be a nonnegative integer")
        if shot["duration_frames"] == 0 or shot["start_frame"] != end:
            raise ValueError(f"Invalid or non-contiguous shot: {shot['name']}")
        transition = shot["transition_in_frames"]
        if transition not in (0,4,6) or (index == 0 and transition != 0):
            raise ValueError("Use 4- or 6-frame centered dissolves, or 0 for a cut")
        keys = shot["crop_center_keyframes"]
        if not keys or keys[0]["frame"] != 0:
            raise ValueError(f"{shot['name']}: crop keyframes must start at frame 0")
        previous = -1
        for key in keys:
            if not isinstance(key["frame"],int) or not previous < key["frame"] <= shot["duration_frames"]:
                raise ValueError(f"{shot['name']}: crop keyframe frames must increase within the shot or at its end boundary")
            if not isinstance(key["cx"],(int,float)) or not 0 <= key["cx"] <= 1:
                raise ValueError(f"{shot['name']}: cx must be normalized to source width, within 0..1")
            previous = key["frame"]
        end += shot["duration_frames"]
    if end != TOTAL_FRAMES:
        raise ValueError(f"Timeline totals {end} frames, expected 720")


def crop_expression(shot):
    """Linear keyframe interpolation in shot-frame time, clamped at both ends."""
    keys = shot["crop_center_keyframes"]
    local = f"clip(n-{shot['source_in_frames']},0,{shot['duration_frames']})"
    expression = f"{keys[-1]['cx']:.8f}"
    for first,last in reversed(list(zip(keys,keys[1:]))):
        slope = (last["cx"]-first["cx"])/(last["frame"]-first["frame"])
        value = f"({first['cx']:.8f}+({local}-{first['frame']})*{slope:.10f})"
        expression = f"if(lt({local},{last['frame']}),{value},{expression})"
    return expression


class SourceReader:
    def __init__(self, root, shot, log_path):
        self.shot = shot
        self.path = source_path(root,shot["file"])
        self.index,self.frame,self.eof = -1,None,False
        self.pre_clamps,self.post_clamps = 0,0
        self.log = log_path.open("wb")
        center = crop_expression(shot)
        # Scale preserves aspect ratio. Crop coordinates remain normalized to
        # source width because the scale is uniform, then clamp within bounds.
        filters = (f"setpts=PTS-STARTPTS,fps={FPS},"
                   f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase:force_divisible_by=2:flags=lanczos,"
                   f"crop={WIDTH}:{HEIGHT}:x='min(max(iw*({center})-ow/2,0),iw-ow)':y='(ih-oh)/2',"
                   "setsar=1,format=rgb24")
        self.process = subprocess.Popen([
            "ffmpeg","-hide_banner","-loglevel","error","-threads","1",
            "-i",str(self.path),"-map","0:v:0","-an","-sn","-dn",
            "-filter_threads","1","-vf",filters,
            "-pix_fmt","rgb24","-f","rawvideo","pipe:1"
        ],stdout=subprocess.PIPE,stderr=self.log)

    def get(self,index,handle=False):
        if index < 0:
            if not handle or index < -MAX_EDGE_HANDLE:
                raise RuntimeError(f"Invalid pre-handle in {self.path.name}")
            self.pre_clamps += 1
            index = 0
        while self.index < index and not self.eof:
            raw = self.process.stdout.read(FRAME_BYTES)
            if not raw:
                self.eof = True
                break
            if len(raw) != FRAME_BYTES:
                raise RuntimeError(f"Incomplete decoded frame from {self.path.name}")
            self.index += 1
            self.frame = np.frombuffer(raw,dtype=np.uint8).reshape(HEIGHT,WIDTH,3)
        if self.frame is None:
            raise RuntimeError(f"No frames decoded from {self.path.name}; inspect its decoder log")
        if self.index < index:
            if not handle or index-self.index > MAX_EDGE_HANDLE:
                raise RuntimeError(f"{self.path.name} is too short; frozen body padding is disabled")
            self.post_clamps += 1
        return self.frame

    def close(self):
        self.process.stdout.close()
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.log.close()
        return {"file":self.shot["file"],"pre_handle_edge_frames":self.pre_clamps,
                "post_handle_edge_frames":self.post_clamps}


def encode_options(args):
    return ["-c:v","libx264","-preset",args.preset,"-crf",str(args.crf),
            "-maxrate","6000k","-bufsize","12000k","-threads","2",
            "-pix_fmt","yuv420p","-g","48","-keyint_min","24",
            "-color_primaries","bt709","-color_trc","bt709","-colorspace","bt709",
            "-video_track_timescale","12288","-movflags","+faststart"]


def render_picture(root,work,master,args,plan):
    shots = plan["shots"]
    windows = []
    for index,shot in enumerate(shots):
        count = shot["transition_in_frames"]
        if count:
            windows.append({"incoming":index,"first":shot["start_frame"]-count//2,
                            "end":shot["start_frame"]+count//2,"frames":count})
    encoder = subprocess.Popen([
        "ffmpeg","-hide_banner","-loglevel","warning","-y",
        "-f","rawvideo","-pix_fmt","rgb24","-s",f"{WIDTH}x{HEIGHT}",
        "-r",str(FPS),"-i","pipe:0","-an","-filter_threads","1",
        "-vf","scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p",
        "-frames:v",str(TOTAL_FRAMES),*encode_options(args),str(master)
    ],stdin=subprocess.PIPE)
    readers,stats = {},[]
    active = 0

    def frame_at(index,timeline_frame,handle=False):
        if index not in readers:
            readers[index] = SourceReader(root,shots[index],work/f"decode-{index+1:02d}.log")
        source_frame = timeline_frame-shots[index]["start_frame"]+shots[index]["source_in_frames"]
        return readers[index].get(source_frame,handle=handle)

    try:
        for index in range(TOTAL_FRAMES):
            while active+1 < len(shots) and index >= shots[active+1]["start_frame"]:
                active += 1
            window = next((w for w in windows if w["first"] <= index < w["end"]),None)
            needed = {window["incoming"]-1,window["incoming"]} if window else {active}
            for old in list(readers):
                if old not in needed:
                    stats.append(readers.pop(old).close())
            if window:
                incoming = window["incoming"]
                outgoing_frame = frame_at(incoming-1,index,handle=True)
                incoming_frame = frame_at(incoming,index,handle=True)
                progress = (index-window["first"]+.5)/window["frames"]
                weight = progress*progress*(3-2*progress)
                frame = cv2.addWeighted(outgoing_frame,1-weight,incoming_frame,weight,0)
            else:
                frame = frame_at(active,index)
            encoder.stdin.write(frame.tobytes())
            if index%(FPS*5) == 0:
                print(f"Rendered portrait reel {index//FPS}/{int(DURATION)}s",flush=True)
        encoder.stdin.close()
        if encoder.wait() != 0:
            raise RuntimeError("Portrait encoder failed")
    except BaseException:
        encoder.kill()
        encoder.wait()
        raise
    finally:
        for reader in readers.values():
            stats.append(reader.close())
    return stats


def mix_audio(root,master,final,plan):
    music = source_path(root,plan["music"])
    if not music.exists():
        raise FileNotFoundError(music)
    fade_in = plan["music_fade_in_seconds"]
    fade_out = plan["music_fade_out_seconds"]
    command = ["ffmpeg","-hide_banner","-loglevel","warning","-y","-i",master,"-i",music]
    filters = [f"[1:a]aresample=48000,aformat=channel_layouts=stereo,"
               f"loudnorm=I={plan['music_target_lufs']}:TP={plan['music_true_peak_db']}:LRA=9,"
               f"apad,atrim=duration=30,afade=t=in:st=0:d={fade_in},"
               f"afade=t=out:st={DURATION-fade_out}:d={fade_out}[music]"]
    labels = ["[music]"]
    sources = [plan["music"]]
    action = plan.get("action_audio")
    if action:
        path = source_path(root,action["file"])
        if any(stream["codec_type"] == "audio" for stream in probe(path)["streams"]):
            command += ["-i",path]
            begin = action["source_in_frames"]/FPS
            length = action["duration_frames"]/FPS
            delay = round(action["start_frame"]/FPS*1000)
            filters.append(f"[2:a]aresample=48000,aformat=channel_layouts=stereo,"
                           f"atrim=start={begin}:end={begin+length},asetpts=PTS-STARTPTS,"
                           f"volume={action['volume']},afade=t=in:st=0:d=0.08,"
                           f"afade=t=out:st={length-.1}:d=0.1,adelay={delay}|{delay},"
                           "apad,atrim=duration=30[action]")
            labels.append("[action]")
            sources.append(action["file"])
    filters.append("".join(labels)+f"amix=inputs={len(labels)}:duration=longest:normalize=0,"
                   "alimiter=limit=0.78:level=false,atrim=duration=30,asetpts=PTS-STARTPTS[mix]")
    command += ["-filter_complex_threads","1","-filter_complex",";".join(filters),
                "-map","0:v:0","-map","[mix]","-c:v","copy","-c:a","aac",
                "-b:a","192k","-ar","48000","-t","30","-movflags","+faststart",final]
    run(command)
    return sources


def validate_video(path,audio=False):
    info = probe(path)
    video = next(s for s in info["streams"] if s["codec_type"] == "video")
    count = video.get("nb_frames")
    if count in (None,"N/A"):
        info = probe(path,count_frames=True)
        video = next(s for s in info["streams"] if s["codec_type"] == "video")
        count = video.get("nb_read_frames")
    numerator,denominator = map(int,video["avg_frame_rate"].split("/"))
    if int(count or -1) != TOTAL_FRAMES or (video["width"],video["height"]) != (WIDTH,HEIGHT) or numerator/denominator != FPS:
        raise RuntimeError(f"{path.name}: expected 720 frames at 1080x1920/24fps")
    duration = float(video.get("duration",0))
    if abs(duration-DURATION) > .001:
        raise RuntimeError(f"{path.name}: video duration is {duration}")
    result = {"frames":int(count),"width":WIDTH,"height":HEIGHT,"fps":FPS,
              "duration":duration,"container_duration":float(info["format"]["duration"]),
              "bytes":path.stat().st_size}
    if audio:
        stream = next((s for s in info["streams"] if s["codec_type"] == "audio"),None)
        if stream is None or stream.get("codec_name") != "aac" or abs(float(stream.get("duration",0))-DURATION) > .025:
            raise RuntimeError("Final must contain exactly 30 seconds of AAC audio")
        if int(stream.get("sample_rate",0)) != 48000:
            raise RuntimeError("Expected 48 kHz audio")
        result["audio_duration"] = float(stream["duration"])
        if abs(result["container_duration"]-DURATION) > .025 or result["bytes"] >= 50_000_000:
            raise RuntimeError("Final must remain 30 seconds and below 50 MB")
    return result


def font_path():
    for path in ["/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
                 "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf","C:/Windows/Fonts/arial.ttf"]:
        if Path(path).exists():
            return path
    raise RuntimeError("A regular sans font is required for review-sheet labels only")


def save_review(sheet,path):
    while True:
        for quality in [88,80,72,64,56,48,40]:
            buffer = io.BytesIO()
            sheet.save(buffer,format="JPEG",quality=quality,optimize=True,progressive=True)
            if buffer.tell() <= 500*1024:
                path.write_bytes(buffer.getvalue())
                return
        sheet = sheet.resize((round(sheet.width*.85),round(sheet.height*.85)),Image.Resampling.LANCZOS)


def review_sheet(root,work,plan,path,final=None):
    width,height,caption = 270,480,32
    shots = plan["shots"]
    sheet = Image.new("RGB",(width*3,(height+caption)*((len(shots)+2)//3)),(19,24,22))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype(font_path(),15)
    for index,shot in enumerate(shots):
        midpoint = shot["duration_frames"]//2
        if final:
            time = (shot["start_frame"]+midpoint)/FPS
            raw = subprocess.check_output([
                "ffmpeg","-hide_banner","-loglevel","error","-ss",str(time),
                "-i",str(final),"-frames:v","1","-an",
                "-vf",f"scale={width}:{height}:flags=lanczos",
                "-f","image2pipe","-vcodec","png","pipe:1"])
            image = Image.open(io.BytesIO(raw)).convert("RGB")
        else:
            reader = SourceReader(root,shot,work/f"preview-{index+1:02d}.log")
            try:
                frame = reader.get(shot["source_in_frames"]+midpoint)
                image = Image.fromarray(frame).resize((width,height),Image.Resampling.LANCZOS)
            finally:
                reader.close()
        x,y = (index%3)*width,(index//3)*(height+caption)
        sheet.paste(image,(x,y))
        start,end = shot["start_frame"]/FPS,(shot["start_frame"]+shot["duration_frames"])/FPS
        draw.text((x+7,y+height+6),f"{start:g}–{end:g}s  {shot['name']}",font=font,fill=(241,237,224))
    save_review(sheet,path)


def terminal_hash(path):
    raw = subprocess.check_output([
        "ffmpeg","-hide_banner","-loglevel","error","-ss",f"{(TOTAL_FRAMES-1)/FPS-.000001:.6f}",
        "-i",str(path),"-map","0:v:0","-frames:v","1","-an",
        "-pix_fmt","rgb24","-f","rawvideo","pipe:1"])
    if len(raw) != FRAME_BYTES:
        raise RuntimeError("The final portrait frame failed to decode")
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--plan",type=Path,default=Path(__file__).resolve().with_name("reel-plan.json"))
    parser.add_argument("--preview",action="store_true")
    parser.add_argument("--audio-only",action="store_true")
    parser.add_argument("--preset",default="veryfast")
    parser.add_argument("--crf",type=int,default=19)
    args = parser.parse_args()
    if args.preview and args.audio_only:
        parser.error("Choose --preview or --audio-only")
    root = args.root.resolve()
    output = root/"reel"
    work = output/"render"
    work.mkdir(parents=True,exist_ok=True)
    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    validate_plan(plan)
    cv2.setNumThreads(1)
    for shot in plan["shots"]:
        path = source_path(root,shot["file"])
        if not path.exists():
            raise FileNotFoundError(path)
    if args.preview:
        review_sheet(root,work,plan,output/"reel-review.jpg")
        print(f"Portrait crop preview: {output/'reel-review.jpg'}",flush=True)
        return
    master,final = output/"video-master-reel.mp4",output/"final30-reel.mp4"
    handle_usage = []
    if not args.audio_only:
        handle_usage = render_picture(root,work,master,args,plan)
    elif not master.exists():
        raise FileNotFoundError("--audio-only requires reel/video-master-reel.mp4")
    master_stats = validate_video(master)
    audio_sources = mix_audio(root,master,final,plan)
    final_stats = validate_video(final,audio=True)
    last_hash = terminal_hash(final)
    if last_hash != terminal_hash(master):
        raise RuntimeError("The audio mux changed the terminal portrait frame")
    review_sheet(root,work,plan,output/"reel-review.jpg",final=final)
    manifest = {"plan":plan,"on_screen_text":[],
                "picture_method":"Full-bleed aspect-preserving Lanczos scale, horizontally tracked crop clamped to source bounds, and fixed-boundary centered cross-mixes. No sharpening, retiming, letterboxing or frozen body padding.",
                "source_handle_usage":handle_usage,"audio_sources":audio_sources,
                "native_audio":"Only original action source 1–3s at reel 2–4s; all other clip audio muted.",
                "outputs":{"video-master-reel.mp4":master_stats,"final30-reel.mp4":final_stats},
                "last_frame_validation":{"decoded":True,"matches_master":True,"sha256":last_hash}}
    (output/"reel-manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(final_stats,indent=2),flush=True)


if __name__ == "__main__":
    main()
