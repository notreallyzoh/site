#!/usr/bin/env python3
"""Fixed-length photographic dissolves and a text-free hovering shoe finale.

Run alongside assemble.py and the supplied assets:
  python assemble_smooth.py --grades grades.json
  python assemble_smooth.py --audio-only

Outputs are separate from the original edit. No title or graphic is rendered.
Only two source decoders are open at a time; each keeps a single RGB frame.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import assemble as base


WIDTH, HEIGHT, FPS, DURATION = 1920, 1080, 24, 60
FRAME_BYTES = WIDTH*HEIGHT*3
MAX_EDGE_HANDLE = 4
SHOTS = [
    {"file":"scene01.mp4", "duration":7, "start":0, "name":"Ascent"},
    {"file":"existing-action.mp4", "duration":5, "start":7, "name":"Footsteps"},
    {"file":"scene02.mp4", "duration":6, "start":12, "name":"Fogbound lookout"},
    {"file":"scene03.mp4", "duration":4, "start":18, "name":"Pause"},
    {"file":"scene04.mp4", "duration":6, "start":22, "name":"Noticing"},
    {"file":"existing-macro.mp4", "duration":4, "start":28, "name":"Material detail"},
    {"file":"scene05.mp4", "duration":5, "start":32, "name":"Small landscape"},
    {"file":"scene06.mp4", "duration":5, "start":37, "name":"Continuing"},
    {"file":"scene08.mp4", "duration":4, "start":42, "name":"Mountain trail run"},
    {"file":"scene09.mp4", "duration":3, "start":46, "name":"Low trail hop"},
    {"file":"scene07.mp4", "duration":5, "start":49, "name":"Alpine panorama"},
    {"file":"existing-forest.mp4", "duration":1, "start":54, "source_in":2, "name":"Matched forest hero"},
    {"file":"scene10-hover.mp4", "duration":5, "start":55, "name":"Hover and slow rotation"},
]
# Total transition frames, centered on each existing cut. No frames are removed.
TRANSITION_LENGTHS = {7:6, 12:8, 18:8, 22:8, 28:6, 32:6, 37:8,
                      42:4, 46:4, 49:4, 54:8, 55:4}


class SourceReader:
    def __init__(self, path, grade, log_path):
        self.path = path
        self.index = -1
        self.frame = None
        self.eof = False
        self.pre_handle_clamps = 0
        self.post_handle_clamps = 0
        self.log = log_path.open("wb")
        filters = f"fps={FPS},"+base.visual_filter(WIDTH,HEIGHT,grade)+",format=rgb24"
        self.process = subprocess.Popen([
            "ffmpeg","-hide_banner","-loglevel","error", "-threads","1",
            "-i",str(path), "-map","0:v:0", "-an","-sn","-dn",
            "-filter_threads","1", "-vf",filters,
            "-pix_fmt","rgb24", "-f","rawvideo", "pipe:1"
        ],stdout=subprocess.PIPE,stderr=self.log)

    def get(self, index, transition_handle=False):
        if index < 0:
            if not transition_handle or index < -MAX_EDGE_HANDLE:
                raise RuntimeError(f"Invalid pre-handle for {self.path.name}: {index}")
            self.pre_handle_clamps += 1
            index = 0
        while self.index < index and not self.eof:
            raw = self.process.stdout.read(FRAME_BYTES)
            if not raw:
                self.eof = True
                break
            if len(raw) != FRAME_BYTES:
                raise RuntimeError(f"Incomplete decoded frame in {self.path.name}")
            self.index += 1
            self.frame = np.frombuffer(raw,dtype=np.uint8).reshape(HEIGHT,WIDTH,3)
        if self.frame is None:
            raise RuntimeError(f"No decoded frames in {self.path.name}")
        if self.index < index:
            missing = index-self.index
            if not transition_handle or missing > MAX_EDGE_HANDLE:
                raise RuntimeError(f"{self.path.name} is too short at frame {index}; general frozen padding is disabled")
            self.post_handle_clamps += 1
        return self.frame

    def close(self):
        if self.process.stdout:
            self.process.stdout.close()
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.log.close()
        return {"file":self.path.name,"pre_handle_edge_frames":self.pre_handle_clamps,
                "post_handle_edge_frames":self.post_handle_clamps}


def boundary_windows():
    windows = []
    for incoming in range(1,len(SHOTS)):
        second = SHOTS[incoming]["start"]
        count = TRANSITION_LENGTHS[second]
        if not count:
            continue
        cut = second*FPS
        windows.append({"incoming":incoming,"cut_seconds":second,"frames":count,
                        "first_frame":cut-count//2,"end_frame":cut+count//2})
    return windows


def render_picture(root, work, master, args, grades):
    command = ["ffmpeg","-hide_banner","-loglevel","warning","-y",
               "-f","rawvideo","-pix_fmt","rgb24", "-s",f"{WIDTH}x{HEIGHT}",
               "-r",str(FPS),"-i","pipe:0", "-an", "-filter_threads","1",
               "-vf","scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p",
               "-frames:v",str(FPS*DURATION), *base.encode_options(args),str(master)]
    encoder = subprocess.Popen(command,stdin=subprocess.PIPE)
    readers, reader_stats = {}, []
    windows = boundary_windows()
    current_shot = 0
    last_frame = None

    def reader(index):
        if index not in readers:
            shot = SHOTS[index]
            readers[index] = SourceReader(root/shot["file"],grades.get(shot["file"]),
                                          work/f"decode-{index+1:02d}.log")
        return readers[index]

    def source_frame(index, timeline_frame, handle=False):
        shot = SHOTS[index]
        local = timeline_frame-shot["start"]*FPS+round(shot.get("source_in",0)*FPS)
        return reader(index).get(local,transition_handle=handle)

    try:
        for frame_index in range(FPS*DURATION):
            while current_shot+1 < len(SHOTS) and frame_index >= SHOTS[current_shot+1]["start"]*FPS:
                current_shot += 1
            window = next((item for item in windows if item["first_frame"] <= frame_index < item["end_frame"]),None)
            needed = {window["incoming"]-1,window["incoming"]} if window else {current_shot}
            for index in list(readers):
                if index not in needed:
                    reader_stats.append(readers.pop(index).close())
            if window:
                incoming = window["incoming"]
                outgoing_frame = source_frame(incoming-1,frame_index,handle=True)
                incoming_frame = source_frame(incoming,frame_index,handle=True)
                progress = (frame_index-window["first_frame"]+.5)/window["frames"]
                weight = progress*progress*(3-2*progress)
                frame = cv2.addWeighted(outgoing_frame,1-weight,incoming_frame,weight,0)
            else:
                frame = source_frame(current_shot,frame_index)
            encoder.stdin.write(frame.tobytes())
            last_frame = frame
            if frame_index%(FPS*5) == 0:
                print(f"Rendered smooth picture {frame_index//FPS}/{DURATION}s",flush=True)
        encoder.stdin.close()
        if encoder.wait() != 0:
            raise RuntimeError("Smooth picture encoder failed")
    except BaseException:
        encoder.kill()
        encoder.wait()
        raise
    finally:
        for source in readers.values():
            reader_stats.append(source.close())
    return reader_stats,last_frame


def decode_last_frame(path):
    second = (FPS*DURATION-1)/FPS-.000001
    raw = subprocess.check_output([
        "ffmpeg","-hide_banner","-loglevel","error",
        "-ss",f"{second:.6f}","-i",str(path),"-map","0:v:0",
        "-frames:v","1","-an","-pix_fmt","rgb24","-f","rawvideo","pipe:1"
    ])
    if len(raw) != FRAME_BYTES:
        raise RuntimeError(f"The terminal frame of {path.name} did not decode fully")
    return raw


def validate_ending(root, work, master, final, grades, expected=None):
    actual = decode_last_frame(final)
    if actual != decode_last_frame(master):
        raise RuntimeError("Final mux changed the terminal picture frame")
    if expected is None:
        source = SourceReader(root/SHOTS[-1]["file"],grades.get(SHOTS[-1]["file"]),
                              work/"verify-ending.log")
        try:
            expected = source.get(SHOTS[-1]["duration"]*FPS-1)
        finally:
            source.close()
    decoded = np.frombuffer(actual,dtype=np.uint8).reshape(HEIGHT,WIDTH,3)
    error = float(cv2.absdiff(decoded,expected).mean())
    if error > 12:
        raise RuntimeError(f"Final frame differs excessively from the hovering source: mean error {error:.2f}")
    return {"decoded":True,"matches_video_master":True,
            "hover_source_mean_error":round(error,3),
            "sha256":hashlib.sha256(actual).hexdigest(),"on_screen_text":[]}


def review_sheet(final, output):
    width,height,label_height = 640,360,30
    sheet = Image.new("RGB",(width*2,(height+label_height)*((len(SHOTS)+1)//2)),(19,24,22))
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype(base.font_path(),17)
    for index,shot in enumerate(SHOTS):
        time = shot["start"]+shot["duration"]/2
        frame = base.extract_frame(final,time,(width,height))
        x,y = (index%2)*width,(index//2)*(height+label_height)
        sheet.paste(frame,(x,y))
        # QA labels sit outside the video frames and are never encoded into film.
        draw.text((x+10,y+height+5),f"{shot['start']:02d}–{shot['start']+shot['duration']:02d}s  {shot['name']}",
                  font=font,fill=base.IVORY)
    base.save_review_jpeg(sheet,output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path.cwd())
    parser.add_argument("--grades",type=Path)
    parser.add_argument("--audio-only",action="store_true")
    parser.add_argument("--forest-ambience",action="store_true")
    parser.add_argument("--mute-action-audio",action="store_true")
    parser.add_argument("--preset",default="veryfast")
    parser.add_argument("--crf",type=int,default=19)
    args = parser.parse_args()
    root = args.root.resolve()
    work = root/"render-smooth"
    work.mkdir(parents=True,exist_ok=True)
    cv2.setNumThreads(1)
    grades = json.loads(args.grades.read_text(encoding="utf-8")) if args.grades else {}
    # The smooth edit adds a new source; retain the base's bounded eq validation
    # by checking its numeric settings against an existing filename.
    for filename,settings in grades.items():
        if filename not in {shot["file"] for shot in SHOTS}:
            raise ValueError(f"Unknown grade asset: {filename}")
        base.validate_grades({"scene01.mp4":settings})
    end = 0
    for shot in SHOTS:
        if shot["start"] != end:
            raise ValueError(f"Non-contiguous timeline at {shot['name']}")
        end += shot["duration"]
        if not (root/shot["file"]).exists():
            raise FileNotFoundError(root/shot["file"])
    if end != DURATION:
        raise ValueError("The smooth timeline must remain exactly 60 seconds")
    master,final = root/"video-master-smooth.mp4",root/"final60-smooth.mp4"
    manifest_path = root/"smooth-manifest.json"
    reader_stats,expected = [],None
    if args.audio_only:
        if not master.exists():
            raise FileNotFoundError("--audio-only requires video-master-smooth.mp4")
        if manifest_path.exists():
            previous = json.loads(manifest_path.read_text(encoding="utf-8"))
            reader_stats = previous.get("source_handle_usage",[])
            if not args.grades:
                grades = previous.get("grades",{})
    else:
        reader_stats,expected = render_picture(root,work,master,args,grades)
    master_stats = base.check_video(master,FPS*DURATION)
    audio_sources = base.mix_audio(root,master,final,forest_ambience=args.forest_ambience,
                                   action_audio=not args.mute_action_audio)
    final_stats = base.check_video(final,FPS*DURATION,expected_audio=True)
    if abs(final_stats["container_duration"]-60) > .025:
        raise RuntimeError("Final container must remain exactly 60 seconds")
    if final_stats["bytes"] >= 50_000_000:
        raise RuntimeError("Final exceeds 50 MB; rerender with --crf 22")
    ending = validate_ending(root,work,master,final,grades,expected)
    review_sheet(final,root/"smooth-review.jpg")
    manifest = {
        "title":"The View — smooth photographic edit", "duration":60,
        "fps":FPS,"frame_count":1440,"resolution":[WIDTH,HEIGHT],
        "timeline":SHOTS,"on_screen_text":[],"grades":grades,
        "transitions":{"method":"Centered cross-mixes replace existing timeline frames without shortening shots or retiming footage. Real source handles are used wherever available; unavailable edge handles repeat at most four source frames only while blended. Body-shot padding is disabled.",
                       "boundaries":[{"second":second,"frames":count} for second,count in TRANSITION_LENGTHS.items()],
                       "hero_to_hover":"Short matched blend at 55 seconds; forest source interval 2–3 seconds followed by generated hovering continuation."},
        "source_handle_usage":reader_stats,
        "audio":{"sources":audio_sources,"new_scene_native_audio":"muted",
                 "footsteps":"Original action audio only at 7–12 seconds" if "existing-action.mp4" in audio_sources else "disabled",
                 "forest_bed":"Enabled after verification" if "existing-forest.mp4" in audio_sources else "disabled",
                 "music":"Existing music.mp3; unchanged generation"},
        "outputs":{"video-master-smooth.mp4":master_stats,"final60-smooth.mp4":final_stats},
        "last_frame_validation":ending,
    }
    manifest_path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(final_stats,indent=2),flush=True)


if __name__ == "__main__":
    main()
